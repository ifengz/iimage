# 媒体生成接入指南

更新日期：2026-09-06

## 1. 边界

NewAPI 负责维护多个上游 URL、上游 Key、渠道优先级和模型路由。下游项目只配置一套：

- `Base URL`
- `API Key`

下游项目通过 `requiredCapabilities` 声明业务需要，再从网关发布的模型目录中选择对应模型：

- `['analysis']`：分析模型。
- `['image']`：生图模型、默认图片尺寸。
- `['analysis', 'image']`：两种模型和默认图片尺寸；未声明时保持此默认行为。
- `['video']`：视频生成模型；可与分析、生图任意组合，例如 `['image', 'video']`。

不要把分析或生图固定到 `default` 等别名。项目自己的提示词、分析 Schema、任务队列、图片裁切和业务状态仍由项目负责。

## 2. 安装与验证

要求 Node.js 18 或更高版本。

```bash
cd media-adapter
npm install
npm test
npm run typecheck
npm run build
npm run example
```

设置示例运行在 `http://127.0.0.1:4173`。它加载 `dist/media-config.js`，不会直接在浏览器中导入 TypeScript。

## 3. 服务端创建客户端

生产项目必须由下游服务端保存 API Key。不要把 Key 写入 localStorage、返回对象、错误信息或浏览器持久化配置。

```ts
import { createConfiguredMediaClient } from 'newapi-media-client/config';

const media = createConfiguredMediaClient(
  {
    baseUrl: process.env.NEWAPI_BASE_URL ?? '',
    analysisModel: selectedAnalysisModel,
    imageModel: selectedImageModel,
    imageSize: '1024x1024',
  },
  process.env.NEWAPI_API_KEY ?? '',
);
```

`createConfiguredMediaClient()` 每次返回独立实例，不使用模块全局连接状态。模型选择和默认图片尺寸注入该实例；调用时仍可用 `options.model` 或 `options.size` 显式覆盖。

纯生图项目通过第三个参数声明需求，未使用的模型字段保留空字符串：

```ts
const projectOptions = { requiredCapabilities: ['image'] as const };
const media = createConfiguredMediaClient(
  {
    baseUrl: process.env.NEWAPI_BASE_URL ?? '',
    analysisModel: '',
    imageModel: selectedImageModel,
    imageSize: '1024x1024',
  },
  process.env.NEWAPI_API_KEY ?? '',
  projectOptions,
);
```

纯分析项目改为 `['analysis']`，填写 `analysisModel`，`imageModel` 可为空。声明必须是非空数组，且只能包含 `analysis`、`image`、`video`；未知值直接报错。需要的模型缺失或只有空白时，创建客户端会失败。

同一份项目声明用于前后端：前端用 `resolveRequiredCapabilities(projectOptions)` 决定展示哪些模型字段、是否展示图片尺寸；保存前用 `validateMediaSettings(settings, projectOptions)` 校验。参考页的 `projectOptions` 是项目接入代码中的声明，不是让终端用户切换业务能力的按钮。服务端使用相同声明创建客户端；只读管理模式由下游项目决定。

`requiredCapabilities` 仅描述必需配置，不是权限控制，也不会移除客户端方法。未声明的能力仍可通过单次调用显式传 `model`；没有配置或传入模型则在请求前报错。`video` 仅代表生成视频，不代表理解上传的视频；现有分析接口仍只接收文字和图片。

`Base URL` 必须是无 URL 凭证、无 query、无 hash 的 HTTP(S) 地址。正常路径前缀允许使用，例如 `https://gateway.example.com/newapi/` 会统一为 `https://gateway.example.com/newapi`。客户端创建和模型发现使用同一校验规则。

## 4. 模型目录

`testConnection({ baseUrl, apiKey })` 只发送一次明确的 `GET /v1/models`，不提交分析、生图或视频任务，不产生媒体生成费用。它默认使用 10 秒内部超时，覆盖连接和响应 body 读取；示例无需自行创建 `AbortSignal`。需要由上层取消时仍可传入外部 `signal`。

响应必须是：

```json
{
  "data": [
    {
      "id": "vision-model-a",
      "supported_endpoint_types": ["openai", "image-understanding"]
    },
    {
      "id": "image-model-a",
      "supported_endpoint_types": ["image-generation"]
    },
    {
      "id": "video-model-a",
      "supported_endpoint_types": ["video-generation"]
    }
  ]
}
```

分类只信任 `supported_endpoint_types`：

- 分析候选必须同时包含 `openai` 和 `image-understanding`。
- 生图候选必须包含 `image-generation`。
- 视频生成候选必须包含 `video-generation`；`video-understanding` 不代表生成能力。
- 不得根据模型 `id`、`owned_by` 或名称片段猜测能力。
- 没有进入任一类别的模型放入 `unclassified`，设置页必须明确显示，不能静默忽略。

下拉框列出对应类别的全部模型。已保存选择只有在本次目录中仍属于合法类别时才保留；失效选择置空，不自动选择 `default` 或唯一候选。

只检查项目声明需要的类别是否有合法候选：纯生图项目不会因为缺少分析或视频候选而报错，其他单能力项目同理。额外的 `unclassified` 仍显示 warning，不会把整个连接标为失败；所需类别缺少候选才显示 error。分类规则不会因项目声明而放宽。

以上标记是适配层接收的明确能力声明，不保证任意网关都会提供。尤其 `video-generation` 的实际发布情况需要检查接入网关；缺失时模型保持未分类，需要上游补充元数据。分类结果也不替代真实视频生成协议的兼容性验证。

HTTP 401/403、其他非 2xx、无效 JSON、非数组 `data`、无效模型 `id` 和网络错误都会归一化为不含 API Key 的结果。

## 5. 非敏感设置

`saveMediaSettings()` 只保存：

```ts
{
  baseUrl,
  analysisModel,
  imageModel,
  imageSize,
  videoModel, // optional; old settings without this field remain valid
}
```

它不会保存或读取 `apiKey`/`token`。参考页的 API Key 输入仅用于当次模型目录请求，请求完成后清空。

`requiredCapabilities` 也不会写入用户存储。`saveMediaSettings()` 保留现有存储职责；需要按项目需求校验时，先调用 `validateMediaSettings()`。

## 6. 分析图片

```ts
const result = await media.analyzeImage(
  '分析商品图',
  ['https://assets.example.com/product.jpg'],
  { jsonSchemaHint: '{"category":"","style":""}' },
);
```

分析使用 `POST /v1/chat/completions` 和 `image_url` content part。设置 `jsonSchemaHint` 时，返回值必须是非数组 JSON 对象；标量、数组、无效 JSON 和空结果都会失败。

## 7. 生成图片

### 文生图和多图输出

```ts
const results = await media.generateImages('商品主图', { size: '1536x1024' });
```

文生图使用 `POST /v1/images/generations`。`generateImages()` 保留网关返回的全部结果和顺序：

- 远程 `url` 原样返回。
- `b64_json` 规范化为 `data:<mime>;base64,...`。
- 空数组、无效项或缺少 `url`/`b64_json` 会直接失败。

`generateImage()` 是严格单图接口。返回多张时它携带完整 `results` 报错，不会静默取 `data[0]`。

### 参考图编辑

```ts
const results = await media.generateImages('保持商品主体，替换背景', {
  images: ['data:image/png;base64,...'],
});
```

传入 `images` 时使用 `POST /v1/images/edits` 和 multipart `image[]`。实例配置的默认图片尺寸同时用于 generations 和 edits；调用时的 `options.size` 可覆盖它。当前合同只接受有效的 image data URI；不接受远程 URL 冒充文件，也不接受非图片 data URI。下游应在提交前限制参考图尺寸和总请求体大小。

### 重试

分析、生图、编辑和视频提交都是可能计费的非幂等 POST。客户端不会自动重投 4xx、5xx、网络失败、空结果或未知结果；调用方也不要在不清楚上游状态时自动重提任务。

## 8. 生成视频

纯视频项目配置如下；未声明视频需求的旧项目不需要新增配置：

```ts
const projectOptions = { requiredCapabilities: ['video'] as const };
const media = createConfiguredMediaClient(
  {
    baseUrl: process.env.NEWAPI_BASE_URL ?? '',
    analysisModel: '',
    imageModel: '',
    imageSize: '1024x1024',
    videoModel: selectedVideoModel,
  },
  process.env.NEWAPI_API_KEY ?? '',
  projectOptions,
);
```

参考 UI 将显示“视频模型”，隐藏分析、生图及图片尺寸字段。把参考页的 `projectOptions` 设为相同声明即可；图片尺寸不是视频分辨率，视频时长和分辨率仍通过调用选项传入。

```ts
const video = await media.generateVideo('海浪拍打礁石', {
  poll_timeout_ms: 15 * 60_000,
  signal: controller.signal,
});
```

调用使用配置中的 `videoModel`；可通过 `options.model` 显式覆盖。分析商品图片再生成视频的项目可以声明 `['analysis', 'video']`，分别选择图片分析模型与视频生成模型。

流程：

1. `POST /v1/video/generations` 提交一次并取得 `task_id`。
2. `GET /v1/video/generations/{task_id}` 轮询。
3. `succeeded` 返回 URL；`failed` 立即失败。
4. 轮询查询的 429、5xx、网络错误和查询超时可继续到 deadline；确定性 4xx 立即失败。
5. deadline 到达后只做一次有独立短超时的最终查询，不重新提交视频任务。

`AbortSignal` 会停止当前请求或轮询，不触发自动重投。

## 9. 下载与 SSRF 边界

```ts
const bytes = await media.download(result.url, {
  timeoutMs: 30_000,
  maxBytes: 25 * 1024 * 1024,
  signal: controller.signal,
});
```

`download()` 支持 base64 data URL 和无凭证的 HTTP(S) URL，并限制超时和响应大小。远程媒体 URL 通常会过期，业务需要长期保存时应立即转存到自己的存储。

服务端不得把不可信用户 URL 直接交给 `download()`。客户端没有 DNS/IP/重定向 host allowlist；生产服务必须在外层限制允许的主机、解析结果、重定向目标和私网地址，避免 SSRF。

## 10. 接入验收

- 下游只有一套 NewAPI `Base URL`/`API Key`，没有上游渠道 URL 或 Key。
- API Key 只保存在下游服务端，不写浏览器持久化。
- 项目声明所需能力，UI 只展示对应模型字段；前后端使用同一份声明校验。
- 所需模型来自显式能力目录，未分类模型可见。
- 未分类模型是 warning；缺少项目所需能力类别才是 error。
- 保存的模型失效后置空，由用户重新选择。
- Base URL 是无凭证、无 query/hash 的 HTTP(S) 地址，可包含路径前缀。
- 项目业务继续管理提示词、Schema、任务和输出归属。
- 非幂等 POST 不自动重试。
- 多图和 base64 输出不丢失。
- 参考图编辑使用 image data URI；提交前限制体积。
- 视频轮询有 deadline、取消和确定性 HTTP 错误处理。
- 服务端下载前执行自己的 SSRF allowlist 策略。
